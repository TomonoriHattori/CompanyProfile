var MpConfig = {
    "documentPath" : "./"
};
